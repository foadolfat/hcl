package com.travel.microservices.destination.model;

import javax.persistence.*;

@Entity
@Table(name="destinationservice")
public class DestinationEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long destId;
	
	@Column(name="place")
	private String place;
	
	@Column(name="country")
	private String country;
	
	@Column(name="latitude")
	private double latitude;
	
	@Column(name="longitude")
	private double longitude;
	
	@Column(name="info")
	private String info;
	
	@Column(name="image")
	private String image;

	public DestinationEntity(Long destId, String place, String country, double latitude, double longitude, String info,
			String image) {
		super();
		this.destId = destId;
		this.place = place;
		this.country = country;
		this.latitude = latitude;
		this.longitude = longitude;
		this.info = info;
		this.image = image;
	}

	public DestinationEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getDestId() {
		return destId;
	}

	public void setDestId(Long destId) {
		this.destId = destId;
	}

	public String getPlace() {
		return place;
	}

	public void setPlace(String place) {
		this.place = place;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public double getLatitude() {
		return latitude;
	}

	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	public double getLongitude() {
		return longitude;
	}

	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getImage() {
		return image;
	}

	public void setImage(String image) {
		this.image = image;
	}

	@Override
	public String toString() {
		return "DestinationEntity [destId=" + destId + ", place=" + place + ", country=" + country + ", latitude="
				+ latitude + ", longitude=" + longitude + ", info=" + info + ", image=" + image + "]";
	}
	
	
	
	
}