package com.travel.microservices.destination.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.travel.microservices.destination.model.DestinationEntity;

@Repository
public interface DestinationRepository extends JpaRepository<DestinationEntity, Long>{

}
