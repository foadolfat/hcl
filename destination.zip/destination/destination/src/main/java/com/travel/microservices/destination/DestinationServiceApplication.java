package com.travel.microservices.destination;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DestinationServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DestinationServiceApplication.class, args);
	}

}
