package com.travel.microservices.destination.controller;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;
import java.util.List;
import com.travel.microservices.destination.model.DestinationEntity;
import com.travel.microservices.destination.service.DestinationService;

@RestController
public class DestinationController {
	private static final Logger LOG = LoggerFactory.getLogger(DestinationController.class);
	
	@Autowired
	DestinationService destinationservice;
	
	@RequestMapping(value = "/destinations/all", method=RequestMethod.GET, produces=("application/json"))
	public ResponseEntity<List<DestinationEntity>> getAllDestinations(){
		List<DestinationEntity> list = destinationservice.getAllDestinations();
		return new ResponseEntity<List<DestinationEntity>>(list, new HttpHeaders(), HttpStatus.OK);
	}
	
	@RequestMapping(value = "/destinations/{id}", method=RequestMethod.GET, produces=("application/json"))
	public ResponseEntity<Optional<DestinationEntity>> getDestinationById(@PathVariable Long id){
		Optional<DestinationEntity> destinationentity = destinationservice.getDestinationById(id);
		return new ResponseEntity<Optional<DestinationEntity>>(destinationentity, new HttpHeaders(), HttpStatus.FOUND);
	}
	
	@RequestMapping(value = "/destinations/create", method=RequestMethod.POST, produces=("application/json"))
	public ResponseEntity<DestinationEntity> createDestination(@RequestBody DestinationEntity destinationDTO){
		DestinationEntity destinationentity = destinationservice.createDestination(destinationDTO);
		return new ResponseEntity<DestinationEntity>(destinationentity, new HttpHeaders(), HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/destinations/update/{id}", method=RequestMethod.PUT, produces=("application/json"))
	public ResponseEntity<Optional<DestinationEntity>> updateDestination(@PathVariable Long id, @RequestBody DestinationEntity destinationDTO){
		Optional<DestinationEntity> destinationentity = destinationservice.updateDestination(id, destinationDTO);
		return new ResponseEntity<Optional<DestinationEntity>>(destinationentity, new HttpHeaders(), HttpStatus.CREATED);
	}
	
	@RequestMapping(value = "/destinations/delete/{id}", method=RequestMethod.DELETE, produces=("application/json"))
	public ResponseEntity createDestination(@PathVariable Long id){
		boolean status = destinationservice.deleteDestinationById(id);
		if(status) return new ResponseEntity(HttpStatus.OK);
		else return new ResponseEntity(HttpStatus.NOT_FOUND);
	}
}
