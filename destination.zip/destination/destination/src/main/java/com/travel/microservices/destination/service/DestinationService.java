package com.travel.microservices.destination.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travel.microservices.destination.model.DestinationEntity;
import com.travel.microservices.destination.repository.DestinationRepository;

@Service
public class DestinationService {
	@Autowired
	DestinationRepository repository;
	
	private static final Logger LOG=LoggerFactory.getLogger(DestinationService.class);
	

	public List<DestinationEntity> getAllDestinations(){
		 List<DestinationEntity> destinationlist = repository.findAll();
         
	        if(destinationlist.size() > 0) {
	            return destinationlist;
	        } else {
	            return new ArrayList<DestinationEntity>();
	        }
	}
	
	public Optional<DestinationEntity> getDestinationById(Long id) {
		Optional<DestinationEntity> result = repository.findById(id);
		return result;
	}
	
	public DestinationEntity createDestination(DestinationEntity destinationDTO) {
		return repository.save(destinationDTO);
	}
	
	//currently, allows changing id as well
	public Optional<DestinationEntity> updateDestination(Long id, DestinationEntity destinationDTO) {
		
		Optional<DestinationEntity> destination = repository.findById(id);
		if(destination.isPresent()) {
			repository.save(destinationDTO);
		}
		return destination;
	}
	
	public boolean deleteDestinationById(Long id) {
		Optional<DestinationEntity> destination = repository.findById(id);
		if(destination.isPresent()) {
			repository.deleteById(id);
			return true;
		}else {
			return false;
		}
		
	}
}
