package com.travel.microservices.destination;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DestinationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
