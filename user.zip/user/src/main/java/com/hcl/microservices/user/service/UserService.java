package com.hcl.microservices.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hcl.microservices.user.model.UserEntity;
import com.hcl.microservices.user.repository.UserRespository;

@Service
public class UserService {
	@Autowired
	UserRespository repository;
	
	private static final Logger LOG=LoggerFactory.getLogger(UserService.class);
	

	public List<UserEntity> getAllEmployees(){
		 List<UserEntity> employeeList = repository.findAll();
         
	        if(employeeList.size() > 0) {
	            return employeeList;
	        } else {
	            return new ArrayList<UserEntity>();
	        }
	}
	
	public Optional<UserEntity> getUserById(Long id) {
		Optional<UserEntity> result = repository.findById(id);
		return result;
	}
}
